import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ViewaccountsPage } from './viewaccounts';

@NgModule({
  declarations: [
    ViewaccountsPage,
  ],
  imports: [
    IonicPageModule.forChild(ViewaccountsPage),
  ],
})
export class ViewaccountsPageModule {}
